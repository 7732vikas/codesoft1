import React from 'react'
import Header from '../components/Header'
import './Home.css'
import apple from'../pages/apple.png'
import  fsss from '../img/fsss.png'
import  veg from '../img/veg.png'
import  pulses from '../img/pulses.png'
import  Footer from '../components/Footer.jsx'
 

 
const Home = () => {
  return (
    <div>
    {/* <Header /> */}
  
    
      <div className='cont'>
             <div className='logo'>
                  <img src={apple}/>
             </div>
             <div className='wrt'>
                         <p>
                            Fresh, Crispy <br/> Heavenly.
                         </p>
                         </div>
                        <div className='wrt-s'>
                                 <p>
                                  100% Organic, vivid varieties of <br/>apples grown in
                                  Kashmir aka The <br/> Heaven of Earth.
                                 </p>
                         </div>
                         <button className='but'>
                                   Buy Now
                         </button>
             
        </div>  
        <Footer/>
    </div>
    
  )
}

export default Home