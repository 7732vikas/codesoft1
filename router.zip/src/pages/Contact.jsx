import React from 'react'
// import Header from '../components/Header'
import './Contact.css'
import map from '../img/map.png'
import phone from '../img/phone.png'
import tele from '../img/tele.png'
import webs from '../img/webs.png'
function Contact() {
  return (
    <div>
      {/* <Header /> */}


      <div className='Contact'>
        <div className='cntlist'>
          <ul className='pt'>
            <li>
              <img src={map} height={40} width={40} />
            </li>
            <li>
              <img src={phone} height={40} width={40} />
            </li>
            <li>
              <img src={tele} height={40} width={40} />
            </li>
            <li>
              <img src={webs} height={40} width={40} />
            </li>
          </ul>
          <ul>
            <li>
              Address:198 West 21th Street ,<br /> Suite 721 New York NY 10016
            </li>
            <li>
              Phone: + 1123 3435 34
            </li>
            <li>
              Email:Kavish12@gmail.com
            </li>
            <li>
              Website:Kavish.com
            </li>
          </ul>
        </div>
      </div>
      <div className='from'>
           <h1>Elegant Contact Form</h1>
           </div>
           <div className='f-cent'>
            <form className='cf'>
                     < div className='half left cf'>
                           <input type='text' id='input-name' placeholder='Name'/>
                           <input type='email' id='input-email' placeholder='Email address'/>
                           <input type='number' id='input-number' placeholder='Your Number'/>
                           <input type='text'  id='input-subject' placeholder='Subject'/>
                     </div>
                     <div className='half right cf'>
                           <textarea name='message' typeof='text'id='input-message' placeholder='Message'/>
                     </div>
                     <input type='submit' value='Submit' className='smt'/>
               </form>
               </div>
      </div>
    
  )
}

export default Contact