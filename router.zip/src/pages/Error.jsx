import React from 'react'
// rfce
function Error() {
  return (
    <div>404</div>
  )
}

export default Error