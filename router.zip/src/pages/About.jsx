import React from 'react'
// import Header from '../components/Header'
import './About.css'
import team1 from '../img/team1.jpg'
import Abhi from '../img/Abhi.jpg'
import team2 from '../img/team2.jpg'
import team3 from  '../img/team3.jpg'
function About() {
  return (
    <div>
      {/* <Header /> */}

      <div className='About'>

        <h1>About Us....</h1>
        <p className='v'>
          Kavish is a leading platform...
        </p>




      </div>
      <br />
      <div className='about-text'>
        <p > Kavish is a leading platform
          that provides computer science resources<br />
          and coding challenges for programmers
          and technology enthusiasts,along <br />with interview
          and exam preparations for upcoming aspirants.<br />
          With a strong emphasis on enhancing coding skills
          and knowledge,it has <br />become a trusted destination
          for over 12 million plus registered users worldwide.
        </p>
      </div>
      <div className='main-box'>
      <div className='boxes'>
        <h2>Our Team</h2>
        <div className='column'>
          <div className='row'>
            <img src={Abhi} height={150} width={150} className='phot' /><br /><br /><br />
            <h3>Vikas Goswami</h3>
            <div className='conttt'>
              <p className='tital'> CEO & Founder</p><br />
              <p>The ability for one <br />business to compose  <br />to provide services.</p><br />
              <p>vikas82@gmail.com</p><br />
              <button class="btn1">Contact</button>
            </div>
          </div>

        </div>
      </div>
      {/* /////////////2///////////// */}
      <div className='boxes'>
        <h2>Our Team</h2>
        <div className='column'>
          <div className='row'>
            <img src={team1} height={150} width={150} className='phot' /><br /><br /><br />
            <h3>Jane Doe</h3>
            <div className='conttt'>
              <p className='tital'> Art Director</p><br />
              <p>Produces art layouts by developing art concepts providing.</p><br />
              <p>jane@example.com</p><br />
              <button class="btn1">Contact</button>
            </div>
          </div>
        </div>
      </div>
           {/* ////////////////3////////////////// */}

           <div className='boxes'>
          <h2>Our Team</h2>
             <div className='column'>
              <div className='row'>
              <img src={team2}  height={150} width={150} className='phot'/><br/><br/><br/>
                      <h3>Mike Ross</h3>
                      <div className='conttt'>
                      <p className='tital'> Designer</p><br/>
                      <p>Some text that <br/>describes me lorem <br/>ipsum ipsum lorem.</p><br/>
                      <p>jane@example.com</p><br/>
                      <button class="btn1">Contact</button>
                      </div>
              </div>

             </div>
            </div>
            {/* ///////////////4//////////////// */}
            <div className='boxes'>
          <h2>Our Team</h2>
             <div className='column'>
              <div className='row'>
              <img src={team3}  height={150} width={150} className='phot'/><br/><br/><br/>
                      <h3>Dane Cook</h3>
                      <div className='conttt'>
                      <p className='tital'> Research Scientist</p><br/>
                      <p>Some text that <br/>describes me lorem <br/>ipsum ipsum lorem.</p><br/>
                      <p>jane@example.com</p><br/>
                      <button class="btn1">Contact</button>
                      </div>
              </div>

             </div>
            </div>
            </div>
    </div>


  )
}

export default About